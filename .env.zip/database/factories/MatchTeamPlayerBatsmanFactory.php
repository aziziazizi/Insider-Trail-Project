<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\MatchTeamPlayerBatsMan;
use Faker\Generator as Faker;

$factory->define(MatchTeamPlayerBatsMan::class, function (Faker $faker) {
    return [
        //
    ];
});
