<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\MatchTeamPlayerRun;
use Faker\Generator as Faker;

$factory->define(MatchTeamPlayerRun::class, function (Faker $faker) {
    return [
        //
    ];
});
