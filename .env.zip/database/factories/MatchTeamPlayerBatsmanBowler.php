<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\MatchTeamPlayerBowler;
use Faker\Generator as Faker;

$factory->define(MatchTeamPlayerBowler::class, function (Faker $faker) {
    return [
        //
    ];
});
