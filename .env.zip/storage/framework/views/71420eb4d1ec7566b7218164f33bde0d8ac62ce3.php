<!doctype html>

<html leng="en">


<head>

     <meta charset="utf-8" >
	 <meta name="viewport" content="width=device-width, initial-scale=1">
	 
    <title> <?php echo $__env->yieldContent('title'); ?></title>
	
	<?php echo $__env->make('includes.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
</head>

<body>

       
	   

	<div id="page_content">
    	<div id="page_content_inner">
			<?php echo $__env->yieldContent('header'); ?>
			<?php echo $__env->yieldContent('contents'); ?>
		</div>
	</div>		
	
	<?php echo $__env->yieldContent('scripts'); ?>




</body>

</html><?php /**PATH C:\xampp2\htdocs\test\resources\views/layouts/master.blade.php ENDPATH**/ ?>