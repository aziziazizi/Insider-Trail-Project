Hello You All,

For Configuration Please Set The Database Name From The .env file
Next
You Should Run The Command
php artisan migrate:fresh

that's all

thank you